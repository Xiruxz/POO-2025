    
package Interfaces;


public interface Autenticable {
     boolean autenticar(String usuario, String password);
}
