
package Interfaces;


public interface Reporteable {
    String generarReporte(String criterio);
}
